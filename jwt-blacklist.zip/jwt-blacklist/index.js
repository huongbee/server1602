const jwtBlacklist = require("./dist/jsonwebtokenb");

module.exports = jwtBlacklist;
